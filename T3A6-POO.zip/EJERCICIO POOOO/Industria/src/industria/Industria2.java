package industria;



    public class Industria2 {
    private double nomina;
    
    public Industria2 (){}

    public Industria2(double nomina) {
        this.nomina = nomina;
    }

    public double getNomina() {
        return nomina;
    }

    public void setNomina(double nomina) {
        this.nomina = nomina;
    }

    @Override
    public String toString() {
        return " SU NOMINA ES: " + nomina;
    }
    
    
}

